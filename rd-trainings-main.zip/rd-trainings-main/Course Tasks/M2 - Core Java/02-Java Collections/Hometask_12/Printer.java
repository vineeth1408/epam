package hometask_12;

import java.util.Arrays;

public class Printer {
	
	public static void printArray(Object[] obj){
		
        System.out.println(Arrays.toString(obj));
    }
}
