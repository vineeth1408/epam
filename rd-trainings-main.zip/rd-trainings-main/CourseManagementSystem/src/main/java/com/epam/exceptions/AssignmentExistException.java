package com.epam.exceptions;

public class AssignmentExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AssignmentExistException(String msg) {
		super(msg);
	}
}
