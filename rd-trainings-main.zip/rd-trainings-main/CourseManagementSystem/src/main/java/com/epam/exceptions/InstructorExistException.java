package com.epam.exceptions;

public class InstructorExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public InstructorExistException(String message) {
		super(message);
	}

}
